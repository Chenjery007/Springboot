package com.example.book_management.controller;

import com.example.book_management.model.Book;
import com.example.book_management.service.BookService;

import jakarta.persistence.EntityNotFoundException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {

    private static final Logger logger = LogManager.getLogger(BookController.class);

    private final BookService bookService;

    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    @GetMapping
    public List<Book> getAllBooks() {
        logger.info("Received request to fetch all books");
        return bookService.getAllBooks();
    }

    @GetMapping("/{id}")
    public Object getBookById(@PathVariable Long id) {
        logger.info("Received request to fetch book with ID: {}", id);  // Log the incoming request

        try {
            Book book = bookService.getBookById(id);
            logger.info("Book found: {}", book);  // Log successful book retrieval
            return new ResponseEntity<>(book, HttpStatus.OK).getBody();
        } catch (EntityNotFoundException e) {
            logger.error("Error fetching book: {}", e.getMessage());  // Log the exception
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);  // Return 404
        }
    }

    @PostMapping
    public Book addBook(@RequestBody Book book) {
        logger.info("Received request to add a new book: {}", book.getTitle());
        return bookService.addBook(book);
    }

    @PutMapping("/{id}")
    public Book updateBook(@PathVariable Long id, @RequestBody Book book) {
        logger.info("Received request to update book with ID: {}", id);
        return bookService.updateBook(id, book);
    }

    @DeleteMapping("/{id}")
    public void deleteBook(@PathVariable Long id) {
        logger.info("Received request to delete book with ID: {}", id);
        bookService.deleteBook(id);
        if (id<=0){
            throw new IllegalArgumentException("ID must be greater than 0");

        }
    }
}