package com.example.book_management.service;

import com.example.book_management.model.Book;
import com.example.book_management.repository.BookRepository;
import com.example.book_management.service.BookService;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookServiceImpl implements BookService {

    private static final Logger logger = LogManager.getLogger(BookServiceImpl.class);

    private final BookRepository bookRepository;

    public BookServiceImpl(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    @Override
    public List<Book> getAllBooks() {
        logger.info("Fetching all books");
        return bookRepository.findAll();
    }

    @Override
    public Book getBookById(Long id) {
        logger.info("Fetching book with ID: {}", id);
        return bookRepository.findById(id).orElseThrow(() -> {
            logger.warn("Book not found with ID: {}", id);
            return new RuntimeException("Book not found");
        });
    }

    @Override
    public Book addBook(Book book) {
        logger.info("Adding a new book: {}", book.getTitle());
        Book savedBook = bookRepository.save(book);
        logger.debug("Saved book details: {}", savedBook);
        return savedBook;
    }

    @Override
    public Book updateBook(Long id, Book updatedBook) {
        logger.info("Updating book with ID: {}", id);
        return bookRepository.findById(id).map(book -> {
            book.setTitle(updatedBook.getTitle());
            book.setAuthor(updatedBook.getAuthor());
            book.setPrice(updatedBook.getPrice());
            logger.debug("Updated book details: {}", book);
            return bookRepository.save(book);
        }).orElseThrow(() -> {
            logger.error("Book not found with ID: {}", id);
            return new RuntimeException("Book not found");
        });
    }

    @Override
    public void deleteBook(Long id) {
        logger.info("Deleting book with ID: {}", id);
        bookRepository.deleteById(id);
    }
}